# title    : 桃園遊憩區遊客人數資料11308
# file     : TaoyuabVistors.R
# date     : 2024.10.02
# author   : Nicole Chien
# email    : nicolechien326@gmail.com
# Encoding : UTF-8

# 安裝 rgl, car 套件
library(rgl)
library(car)

# 匯入 資訊開放平台-11308.csv 資料
urls <- "https://data.tycg.gov.tw/opendata/datalist/datasetMeta/download?id=19d87cc9-d0f0-4212-b038-1b4029909a08&rid=10ab597b-16ec-4260-85cc-7c35c6c0ed1e" 

# 資訊開放平台-11308 <- read.csv(urls, header=TRUE, sep=",")
資訊開放平台_11308 <- read.csv(urls, header=TRUE, sep=",")
TaoyuanVistors
https://data.tycg.gov.tw/opendata/datalist/datasetMeta/download?id=19d87cc9-d0f0-4212-b038-1b4029909a08&rid=10ab597b-16ec-4260-85cc-7c35c6c0ed1e

# 資料結構
str(TaoyuanVisitors) # 20*7

# 資料摘要: 增減數及成長率 有N/A值
summary(TaoyuanVisitors)

# 直方圖
hist(TaoyuanVisitors$成長率)

# 計算 成長率 的中位數
TaoyuanVisitorsDevMedian <- median(TaoyuanVisitors$dev, na.rm=TRUE)

# 以中位數填補 成長率 遺漏值 (missing values)
TaoyuanVisitors$dev[is.na(TaoyuanVisitors$dev)] <- TaoyuanVisitorsdevMedian

# 資料摘要, 成長率 沒有NA值
summary(TaoyuanVisitors)

# 散佈圖矩陣!有發現什麼樣式(patterns)嗎?
pairs(TaoyuanVisitors, pch=16, cex=0.5)

# 建立線性模型
TaoyuanVisitors_lm <- lm(備註 ~ ., data=TaoyuanVisitors)

# newspaper: p值沒有小於0.05,考慮刪除此變數
summary(TaoyuanVisitors_lm)

# 建立修正後線性模型
TaoyuanVisitors_lm_revised <- lm(成長率 ~ 觀光遊憩區別 + 遊客人數, data=TaoyuanVisitors)

summary(TaoyuanVisitors_lm_revised)

# 繪製3d圖
scatter3d(成長率 ~ 觀光遊憩區別 + 遊客人數, data=TaoyuanVisitors, surface=FALSE)

# 加上線性預測
scatter3d(成長率 ~ 觀光遊憩區別 + 遊客人數, data=TaoyuanVisitors)

# 加上2次式預測
scatter3d(成長率 ~ 觀光遊憩區別 + 遊客人數, data=TaoyuanVisitors, fit="quadratic") 

# 加上平滑預測
scatter3d(成長率 ~ 觀光遊憩區別 + 遊客人數, data=TaoyuanVisitors, fit="smooth") 

# 顯示3筆 outliers
scatter3d(成長率 ~ 觀光遊憩區別 + 遊客人數, data=TaoyuanVisitors, id=list(n=3))
# end

