library(shiny)
library(leaflet)
library(geosphere)  # 用於計算兩個經緯度之間的距離
Sys.setenv(TZ = "Asia/Taipei")  # 設置時區為台北時間
library(DBI)
library(RMariaDB)
library(dotenv)
library(dplyr)
# 獲取環境變數
db_name <- Sys.getenv("DB_NAME")
db_host <- Sys.getenv("DB_HOST")
db_user <- Sys.getenv("DB_USER")
db_password <- Sys.getenv("DB_PASSWORD")
# 創建連接到 MySQL 的連接對象
con <- dbConnect(RMariaDB::MariaDB(),
                 dbname = db_name,
                 host = db_host,
                 port = 3306,
                 user = db_user,
                 password = db_password)
# 測試連接：列出所有資料表
dbListTables(con)
# 關閉連接
#dbDisconnect(con)

device <- dbGetQuery(con, "SELECT * FROM device")
device_dongyanshan <- dbGetQuery(con, "SELECT * FROM device_dongyanshan")
device_hsinming <- dbGetQuery(con, "SELECT * FROM device_hsinming")
device_taichung <- dbGetQuery(con, "SELECT * FROM device_taichung")
device_turtlemountain <- dbGetQuery(con, "SELECT * FROM device_turtlemountain")
peopleflowmonitoring <- dbGetQuery(con, "SELECT * FROM peopleflowmonitoring")



# 將所有資料表存入列表
data_tables <- list(
  device_dongyanshan = device_dongyanshan,
  device_taichung = device_taichung,
  device_turtlemountain = device_turtlemountain,
  device_hsinming = device_hsinming
)

# 定義 UI
ui <- fluidPage(
  titlePanel("利用里程碑公里數預測到達目的地所需時間"),
  #選擇資料表
  titlePanel("選擇資料表"),
  sidebarLayout(
    sidebarPanel(
      selectInput("table", "選擇資料表:", choices = names(data_tables)),
      actionButton("load", "載入資料")
    ),
    mainPanel(
      tableOutput("data_table"),
      textOutput("nearbyPoint"),  # 顯示與使用者接近的資料點
    )
  ),
  # leafletOutput 用來顯示地圖
  titlePanel("Geolocation with Leaflet"),
  leafletOutput("mymap", height = 600),
  textOutput("latitude"),
  textOutput("longitude"),
  textOutput("altitude"),
  textOutput("speed"),
  textOutput("heading"),
  textOutput("altitudeAccuracy"),
  textOutput("real_time"),
  titlePanel("使用者資料"),
  tableOutput("walk_data"),
  titlePanel("預估時間"),
  tableOutput("forecast_walk_data"),

  # 加載 JavaScript 來持續監聽位置
  tags$script(
    HTML(
      "
      if (navigator.geolocation) {
        navigator.geolocation.watchPosition(successCallback, errorCallback, {
          enableHighAccuracy: true,
          timeout: Infinity,
          maximumAge: 0
        });
      } else {
        alert('您的瀏覽器不支援GPS功能。');
      }
      
      function successCallback(position) {
        var lati = position.coords.latitude;
        var longi = position.coords.longitude;
        
        // 將位置數據發送回 R 後端
        Shiny.setInputValue('latitude', lati);
        Shiny.setInputValue('longitude', longi);
      }
      
      function errorCallback(error) {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            alert('請在您的裝置設定中啟用 GPS 以使用位置功能。');
            break;
          case error.POSITION_UNAVAILABLE:
            alert('位置資訊不可用。請檢查您的 GPS 設定。');
            break;
          case error.TIMEOUT:
            alert('取得用戶位置的請求逾時。請再試一次。');
            break;
          case error.UNKNOWN_ERROR:
            alert('發生未知錯誤。請再試一次。');
            break;
          default:
            break;
        }
      }
      "
    )
  )
)

# 定義 Server
server <- function(input, output, session) {
  # 3D 距離計算函數
  calculate_3d_distance <- function(lat1, lon1, elev1, lat2, lon2, elev2) {
    horizontal_distance <- distHaversine(c(lon1, lat1), c(lon2, lat2))
    altitude_difference <- elev2 - elev1
    total_3d_distance <- sqrt(horizontal_distance^2 + altitude_difference^2)
    return(total_3d_distance)
  }
  # 初始化地圖並顯示使用者的位置
  output$mymap <- renderLeaflet({
    leaflet() %>%
      addTiles() %>%
      setView(lng = 121.21655, lat = 24.95628, zoom = 15)
  })
  
  # 當使用者的位置數據改變時立即顯示使用者的位置
  observe({
    req(input$latitude, input$longitude)  # 確保有地理位置資料
    leafletProxy("mymap") %>%
      setView(lng = input$longitude, lat = input$latitude, zoom = 15) %>%
      addMarkers(lng = input$longitude, lat = input$latitude, popup = "You are here!")
  })
  # 合併peopleflowmonitoring跟device_turtlemountain的資料成merged_data
  merged_data <- peopleflowmonitoring %>%
    full_join(device_turtlemountain, by = "name")
  walk_data <- merged_data %>%
    select(id = id.y, name, latitude, longitude, elevation_m, real_time) %>%
    mutate(real_time = as.POSIXct(real_time, origin = "1970-01-01", tz = "UTC"),
           real_time = format(real_time, "%Y-%m-%d %H:%M:%S")) %>%  # 將時間格式化為字符串
    arrange(id)  # 可以選擇是否需要依據某個欄位進行排序
  

  
  
  
  
  
  
  
  
  # 監聽 "load" 事件來選擇資料表並顯示資料
  observeEvent(input$load, {
    # 取得選擇的資料表
    selected_table <- data_tables[[input$table]]
    
    # 將主表與選擇的資料表進行 join
    data <- device %>%
      filter(sheet == input$table) %>%
      left_join(selected_table, by = c("id" = "device_id"))
    
    
    # 計算 walk_data 並更新
    walk_data <- merged_data %>%
      select(id = id.y, name, latitude, longitude, elevation_m, real_time) %>%
      mutate(real_time = as.POSIXct(real_time, origin = "1970-01-01", tz = "UTC"),
             real_time = format(real_time, "%Y-%m-%d %H:%M:%S")) %>%
      arrange(id)
    forecast_walk_data<-walk_data
    # 計算距離
    forecast_walk_data$excerpt_distance <- 0
    excerpt_distance <- c(0)
    total_distance <- 0
    for (i in 1:(nrow(forecast_walk_data) - 1)) {
      segment_distance <- calculate_3d_distance(
        forecast_walk_data$latitude[i], forecast_walk_data$longitude[i], forecast_walk_data$ elevation_m[i],
        forecast_walk_data$latitude[i + 1], forecast_walk_data$longitude[i + 1], forecast_walk_data$elevation_m[i + 1]
      )
      forecast_walk_data$excerpt_distance[i + 1] <- segment_distance
      total_distance <- total_distance + segment_distance
      excerpt_distance <- c(excerpt_distance, total_distance)
    }
    forecast_walk_data$total_distance <- c(excerpt_distance)
    #計算速率
    time_values <- forecast_walk_data$real_time[!is.na(walk_data$real_time)]
    forecast_walk_data$speed <- 0 
    for (i in 2:length(time_values)) {
      time_diff <- as.numeric(difftime(forecast_walk_data$real_time[i], forecast_walk_data$real_time[i - 1], units = "hours"))
      if (time_diff > 0) {
        forecast_walk_data$speed[i] <- forecast_walk_data$excerpt_distance[i] / time_diff  # 計算速率，單位是公尺/小時
      }
    }
    # 平均速率
    valid_speeds <- na.omit(forecast_walk_data$speed[2:length(time_values)])  # 移除 NA 的速率值
    if (length(valid_speeds) > 0) {
      mean_speed <- mean(valid_speeds)  # 前幾段的平均速率
    } else {
      mean_speed <- 0  # 若無有效速率，設為 0
    }
    #預測
    for (i in (length(time_values) + 1):nrow(forecast_walk_data)) {  # 從第一個 NA 的時間索引開始
      if (is.na(forecast_walk_data$real_time[i]) && mean_speed > 0) {
        # 確保前一個點的時間存在
        if (!is.na(forecast_walk_data$real_time[i - 1])) {
          # 根據平均速率估計時間差，單位為小時
          time_diff_estimated <- forecast_walk_data$excerpt_distance[i] / mean_speed
          
          # 將前一個時間轉換為 POSIXct，並指定正確的格式
          previous_time <- as.POSIXct(forecast_walk_data$real_time[i - 1], format = "%Y-%m-%d %H:%M:%S", tz = "UTC")
          
          # 將時間差轉化為秒並加到前一個時間
          new_time <- previous_time + (time_diff_estimated * 3600)
          
          # 將結果轉換回指定的字符格式
          forecast_walk_data$real_time[i] <- format(new_time, "%Y-%m-%d %H:%M:%S")
        }
      }
    }
    #預測表格
    output$forecast_walk_data <- renderTable({
      forecast_walk_data
    })
    # 顯示登山路線表格
    output$walk_data <- renderTable({
      walk_data
    })
    
    
    
    
    
    
    
    
    
    
    
    
    
    # 顯示結果表格
    output$data_table <- renderTable({
      data
    })
    # 比較當前 GPS 位置與每個資料點之間的距離。如果距離小於某個門檻（例如 10 米），則可以認為兩個位置接近。
    output$nearbyPoint <- renderText({
      # 當使用者的位置數據改變時檢測附近的資料點
      if (!is.null(input$latitude) && !is.null(input$longitude)) {
        user_location <- c(input$longitude, input$latitude)
        threshold <- 50  # 設置門檻距離為10米
        # 遍歷 data 檢查與每個點的距離
        for (i in 1:nrow(data)) {
          point_location <- c(data$longitude[i], data$latitude[i])
          dist <- distHaversine(user_location, point_location)  # 計算距離
          
          if (dist < threshold) {
            # 新增數據
            name <- data$name[i]
            latitude <- data$latitude[i]  # 轉換為整數
            longitude <- data$longitude[i]  # 轉換為整數
            elevation_m <- data$elevation_m[i]  # 轉換為整數
            real_time <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
            device_id <- data$id[i]
            dbExecute(con,"INSERT INTO peopleflowmonitoring (name,real_time,device_id) VALUES (?, ?,?)", params = list(name, real_time,device_id))
            return(paste("寫入-接近資料點: ",name ,"時間: ",real_time, "，距離: ", round(dist, 2), "，區域: ", device_id))
          }
        }
        return("沒有接近的資料點")
      }
      return("沒有位置數據")
    })
    # 在地圖上顯示資料表的資料點
    leafletProxy("mymap") %>%
      clearMarkers() %>%  # 清除先前的標記
      clearShapes() %>%   # 清除先前的形狀（圓點）
      setView(lng = ifelse(!is.null(input$longitude), input$longitude, 121.21655),
              lat = ifelse(!is.null(input$latitude), input$latitude, 24.95628), zoom = 15) %>%
      addMarkers(lng = ifelse(!is.null(input$longitude), input$longitude, 121.21655),
                 lat = ifelse(!is.null(input$latitude), input$latitude, 24.95628), popup = "You are here!")
    
    for (i in 1:nrow(data)) {
      leafletProxy("mymap") %>%
        addCircleMarkers(
          lng = data$longitude[i],
          lat = data$latitude[i],
          radius = 5,
          label = data$name[i],
          popup = paste(data$name[i], "<br>lat:", data$latitude[i], "<br>lon:", data$longitude[i])
        )
    }
  })
  
  # 顯示使用者的定位信息
  output$latitude <- renderText({
    paste("緯度: ", input$latitude)
  })
  output$longitude <- renderText({
    paste("經度: ", input$longitude)
  })
  output$altitude <- renderText({
    paste("海拔: ", input$altitude)
  })
  output$speed <- renderText({
    paste("速度: ", input$speed)
  })
  output$heading <- renderText({
    paste("方向: ", input$heading)
  })
  output$altitudeAccuracy <- renderText({
    paste("海拔準確度: ", input$altitudeAccuracy)
  })
  output$real_time <- renderText({
    paste("時間: ", input$real_time)
  })
  # 顯示結果表格
  output$walk_data <- renderTable({
    walk_data
  })
}

# 啟動應用程式
shinyApp(ui = ui, server = server)