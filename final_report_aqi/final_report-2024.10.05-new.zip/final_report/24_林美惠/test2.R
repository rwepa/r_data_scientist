# https://github.com/trafficonese/leaflet.extras2/blob/master/inst/examples/heightgraph_app.R
library(shiny)
library(leaflet)
library(leaflet.extras2)
library(sf)        # 處理空間數據
library(sfheaders) # 將數據轉換為 sf 格式
library(jsonlite)  # 讀取和處理 JSON 格式的數據
library(dplyr)     # 數據操作和變換
workpath <- "C:/rdata"
setwd(workpath)
# 指定要讀取的 GeoJSON 文件的路徑。
geojson_file <- "TrailRouteGeoJSON.geojson"
# 使用 fromJSON 函數從指定的 GeoJSON 文件中讀取數據。
geojson_data <- fromJSON(geojson_file)
# 提取 GeoJSON 中的特徵（features）。
features <- geojson_data$features
#print(features)
#type geometry.type                                            geometry.coordinates attributeType
#1 Feature    LineString 121.40807, 121.45262, 24.83122, 24.79206, 882.00000, 1707.00000      東滿步道

# 對每一個特徵使用 lapply，開始處理它們。
data_list <- lapply(features, function(feature) {
  # 提取每個特徵的幾何座標。
  coords <- feature$geometry$coordinates
  #print(coords)
  #[,1]     [,2] [,3]
  #[1,] 121.4081 24.83122  882
  #[2,] 121.4526 24.79206 1707
  # 打印 coords 的结构
  
  # 检查坐标格式
  if (is.null(coords) || length(coords) == 0) {
    stop("坐标数据为空")
  }
  
  # 如果是列表，将其转换为矩阵
  if (is.list(coords)) {
    coords <- do.call(rbind, coords)
  }
  
  # 检查 coords 是否为二维数组
  if (is.matrix(coords) && ncol(coords) >= 3) {
    # 创建数据框
    feature_df <- data.frame(
      X = coords[, 1],
      Y = coords[, 2],
      elev = coords[, 3],
      attributeType = feature$properties$attributeType
    )
  } else {
    stop("坐标数据格式不正确或坐标维度不足")
  }
})

#print(data_list)
#         X        Y elev attributeType
#1 121.4081 24.83122  882      東滿步道
#2 121.4526 24.79206 1707      東滿步道
# 將所有的數據框合併為一個大的數據框。
data <- do.call(rbind, data_list)


# 為每一條線生成一個識別碼（L1），將其轉換為因子。
data$L1 <- as.factor(rep(1:length(features), sapply(data_list, nrow)))
# 使用 mutate 創建一個名為 popup 的新列，格式化為顯示陡峭度、適合度和類型的字符串。
data <- data %>%
  mutate(popup = sprintf("Type: %s<br>Elevation: %s", 
                         attributeType, elev))
#print(data)
#X        Y elev attributeType L1                             popup
#1 121.4081 24.83122  882      東滿步道  1  Type: 東滿步道<br>Elevation: 882
#2 121.4526 24.79206 1707      東滿步道  1 Type: 東滿步道<br>Elevation: 1707

# 將數據轉換為 LINESTRING 格式，以便在 Leaflet 中使用。
data_sf <- sfheaders::sf_linestring(data, x = "X", y = "Y", z = "elev", linestring_id = "L1", keep = TRUE)
# 确保 data_sf 结构正确
#print(data_sf)

# 将 elev 列的值存储为列表
data_sf$elev <- list(as.numeric(data$elev))



# 開始定義用戶界面（UI）。
ui <- fluidPage(
  leafletOutput("map", height = "700px"),
)

server <- function(input, output, session) {
  output$map <- renderLeaflet({
    leaflet() %>%
      addTiles(group = "base") %>%
      #addMarkers(data = data, ~X, ~Y, popup = ~popup) %>%
      addHeightgraph(
        color = "red",
        columns = c("elev"), 
        data = data_sf, 
        group = "heightgraph",
        options = heightgraphOptions(
          width = 800,
          highlightStyle = list(weight = 10, opacity = 0.8, color = 'orange'),
          translation = list(
            distance = "距离", 
            elevation = "海拔", 
            segment_length = "段长度", 
            type = "类型", 
            legend = "图例"
          ),
          xTicks = 3
        )
      ) %>%
      addLayersControl(baseGroups = "base", overlayGroups = "heightgraph")
  })
}

shinyApp(ui, server)
