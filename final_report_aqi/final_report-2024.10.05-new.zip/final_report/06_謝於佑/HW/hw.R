library(readxl)
library(dplyr)
library(ggplot2)
library(corrplot)
library(caret)

# 假設您的資料檔名為 "orginal.xlsx"
data <- read_excel("orginal.xlsx")

# 檢視資料結構
str(data)

# 檢視前幾行資料
head(data)

# 檢查是否有缺失值
sum(is.na(data))

# 2. 資料預處理

# 將百分比列轉換為數值型態（假設它們當前是字符型）
percent_columns <- c("正在接受職業訓練比率", "正在軍中服役比率", "需要工作而未找到比率", 
                     "補習或準備升學比率", "健康不良在家休養比率", "準備出國比率", "其他比率")

data[percent_columns] <- lapply(data[percent_columns], function(x) as.numeric(sub("%", "", x)) / 100)

# 3. 探索性資料分析（EDA）

# 計算各比率的平均值
summary(data[percent_columns])

# 繪製相關係數熱圖
correlation_matrix <- cor(data[percent_columns])
corrplot(correlation_matrix, method = "color")

# 畫出各比率的箱型圖
boxplot(data[percent_columns], main="各就業狀況比率分布", las=2)

# 4. 回歸分析

# 以 "需要工作而未找到比率" 為目標變數，其他比率為預測變數
model <- lm(需要工作而未找到比率 ~ 正在接受職業訓練比率 + 正在軍中服役比率 + 
              補習或準備升學比率 + 健康不良在家休養比率 + 準備出國比率 + 其他比率, data = data)

# 顯示模型摘要
summary(model)

# 5. 模型評估和預測

# 使用 10 折交叉驗證評估模型
set.seed(123)
cv_model <- train(需要工作而未找到比率 ~ 正在接受職業訓練比率 + 正在軍中服役比率 + 
                    補習或準備升學比率 + 健康不良在家休養比率 + 準備出國比率 + 其他比率,
                  data = data,
                  method = "lm",
                  trControl = trainControl(method = "cv", number = 10))

print(cv_model)

# 預測
new_data <- data.frame(
  正在接受職業訓練比率 = 0.05,
  正在軍中服役比率 = 0.1,
  補習或準備升學比率 = 0.2,
  健康不良在家休養比率 = 0.01,
  準備出國比率 = 0.05,
  其他比率 = 0.1
)

predicted_value <- predict(model, newdata = new_data)
print(paste("預測的需要工作而未找到比率：", round(predicted_value, 4)))

# 繪製實際值vs預測值散點圖
plot(data$需要工作而未找到比率, predict(model), 
     main = "實際值 vs 預測值",
     xlab = "實際值", ylab = "預測值")
abline(0, 1, col = "red")

