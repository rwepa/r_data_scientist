library(openair)
library(corrplot)
pdf("openair.pdf")
mtcars
mtcars_car <- cor(mtcars)
mtcars_car
corrplot(mtcars_car)

plot(runif(10), type="b", main="R大數據分析")
x <- rnorm(10)
x
pairs(iris[-5], pch=16, col=iris$Species, main="RWEPA")
y <- runif(10000)
mean(y)
system.time(mean(y))
install.packages("rmarkdown")
tinytex::install_tinytex()
iris$Sepal.Length[145]
plot(runif(100), type="l", main="R大數據分析")
help.start()
?plot
install.packages("e1071")
library(e1071)
sessionInfo()
x1 <- c(1,2,3)
x1
print(x1)
x2 <- seq(1, 10, by=0.5)
x2
mean(x2)
x3 <- c(1, 2, 3, "台北", "新北")
x3
x3new <- iconv(x3, from = "UTF-8", to ="UTF-8")
mean(x3)#ERROR
mean(x3, na.rm = TRUE)
mean(x3new, na.rm = TRUE)
exp(1)
log(exp(1))
log(exp(2))
log10(1000)
exp(x1)
month.abb
month.name
0/0
is.infinite(0/0)
is.finite(0/0)
getwd()
workpath <- "D:/aws"
myFile <- "D:/aws/aqx_p_434.csv"
sq <- read.table(myFile, header=TRUE, sep=",")
head(sq)
names(sq)
dim(sq)
sqBanqiao <- sq[sq$sitename == "板橋",]
sqBanqiao <- sqBanqiao[order(sqBanqiao$monitordate),]
sqTayuan <- sq[sq$sitename == "永和",]
sqTayuan <- sqTayuan[order(sqTayuan$monitordate),]
View(sqBanqiao)
View(sqTayuan)
plot(sqBanqiao$aqi, type="b")
plot(sqTayuan$aqi, type="b")
lines(sqBanqiao$aqi, col="red")
axis(side=1, at=1:12, labels = sqBanqiao$monitordate)
axis(side=2, las = 2)
legend("topleft", legend=c("板橋", "永和"), col=c(1,2), lty=1)
grid()
box()


