# 載入必要的 R 套件
library(dplyr)
library(ggplot2)
library(knitr)
library(rmarkdown)

install.packages("dplyr")  # 如果尚未安裝
install.packages
install.packages

# 讀取CSV檔案
data <- read.csv("全國各鄉鎮市區電信信令人口統計資料日間活動人口-1.csv")

# 查看資料結構
str(data)

# 假設我們要計算每個鄉鎮的平日下午活動人數
summary_data <- data %>%
  group_by(鄉鎮市區名稱) %>%
  summarise(平日下午活動人數 = mean(平日下午活動人數, na.rm = TRUE))   # 計算平日下午活動人數的平均值

# 顯示計算結果
print(summary_data)

# 查看摘要數據
print(summary_data)

# 繪製資料的圖表
plot <- ggplot(summary_data, aes(x = reorder(鄉鎮市區名稱, -平日下午活動人數), y = 平日下午活動人數)) +
  geom_bar(stat = "identity") +  # 使用統計為"identity"，表示 y 值已直接提供
  coord_flip() +  # 使圖表橫向顯示
  labs(title = "各鄉鎮日間活動人口數", x = "鄉鎮市區名稱", y = "平均活動人口") +
  theme_minimal()  # 使用簡約主題

# 顯示圖表
print(plot)

# 將圖表保存為PDF
pdf("活動人口統計_1.pdf")
print(plot)
dev.off()

# 將摘要數據轉換為Markdown格式，保存為另一PDF
rmarkdown::render("summary_report.Rmd") # 假設你有一個summary_report.Rmd文件

